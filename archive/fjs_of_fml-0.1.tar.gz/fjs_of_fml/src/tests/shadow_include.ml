let external_def a b =
  42

let rec external_rec_def a b =
  43
