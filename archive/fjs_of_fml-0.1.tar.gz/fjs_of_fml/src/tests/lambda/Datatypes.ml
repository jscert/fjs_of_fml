type nat =
| O [@f]  (* Auto Generated Attributes *)
| S  [@f label0] of nat (* Auto Generated Attributes *)

