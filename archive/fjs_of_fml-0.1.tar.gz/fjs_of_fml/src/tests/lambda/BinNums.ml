type positive =
| XI  [@f label0] of positive (* Auto Generated Attributes *)
| XO  [@f label0] of positive (* Auto Generated Attributes *)
| XH [@f]  (* Auto Generated Attributes *)

type coq_Z =
| Z0 [@f]  (* Auto Generated Attributes *)
| Zpos  [@f label0] of positive (* Auto Generated Attributes *)
| Zneg  [@f label0] of positive (* Auto Generated Attributes *)

